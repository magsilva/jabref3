package ris;

import net.sf.jabref.*;
import net.sf.jabref.export.layout.*;

public class RisPages implements LayoutFormatter {

	public String format(String s) {
		if (s == null)
			return "";
		StringBuilder sb = new StringBuilder();
		String[] pageParts = s.split("[\\-]+");
		if (pageParts.length == 2) {
			sb.append("SP  - ");
			sb.append(pageParts[0]);
			sb.append(Globals.NEWLINE);
			sb.append("EP  - ");
			sb.append(pageParts[1]);
		}
		return sb.toString();
	}
}