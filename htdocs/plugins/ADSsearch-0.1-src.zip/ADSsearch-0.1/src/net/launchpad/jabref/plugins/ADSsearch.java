/*
 * Copyright (c) 2011 by Alexander Hug <alexander@alexanderhug.info>
 *
 * Based on ADSFetcher (c) 2009 Ryo IGARASHI <rigarash@gmail.com>.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS "AS IS" AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE REGENTS AND CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 * Description of ADS API
 * http://ads.ari.uni-heidelberg.de/abs_doc/help_pages/linking.html
 */
package net.launchpad.jabref.plugins;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;

import javax.imageio.ImageIO;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;

import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JSeparator;

import net.sf.jabref.GUIGlobals;
import net.sf.jabref.Globals;
import net.sf.jabref.OutputPrinter;

import net.sf.jabref.BibtexEntry;
import net.sf.jabref.BibtexDatabase;
import net.sf.jabref.imports.BibtexParser;

import net.sf.jabref.imports.EntryFetcher;
import net.sf.jabref.gui.ImportInspectionDialog;
import net.sf.jabref.imports.ImportInspector;
import net.sf.jabref.imports.ParserResult;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * This class handles accessing and obtaining BibTeX entry
 * from ADS(The NASA Astrophysics Data System) including abstracts.
 *
 *
 * @author Alexander Hug
 * @version $Id$
 */
public class ADSsearch implements EntryFetcher {

    static Log log = LogFactory.getLog(ADSsearch.class);
    //private static final String ADSURL = "http://ads.ari.uni-heidelberg.de";
    private JCheckBox exactCheckBox = new JCheckBox(Globals.lang("Exact author search"), false);
    private static final JLabel lbm = new JLabel("Select a mirror");
    private JTextField tf1 = new JTextField("", 20);
    private JTextField tf2 = new JTextField("", 20);
    private final keyVal[] ckv = {
        new keyVal("None or special keyword", "", ""),
        new keyVal("Author", "author=", "aut_req=YES"),
        new keyVal("First author", "author=^", "aut_req=YES"),
        new keyVal("Title", "title=", "ttl_req=YES"),        
        new keyVal("Keyword", "keyword=", "kwd_req=YES"),
        new keyVal("Year from", "start_year=", ""),
        new keyVal("Year to", "end_year=", ""),
        new keyVal("DOI", "doi=", ""),
        new keyVal("Volume", "volume=", ""),
        new keyVal("Page", "page=", "")};
    private final keyVal[] mirror = {
        new keyVal("Heidelberg, Germany","http://ads.ari.uni-heidelberg.de",""),
        new keyVal("Garching, Germany","http://esoads.eso.org",""),
        new keyVal("Cambridge, USA", "http://adsabs.harvard.edu",""),
        new keyVal("Strasbourg, France","http://cdsads.u-strasbg.fr",""),
        new keyVal("Nottingham, UK","http://ukads.nottingham.ac.uk",""),
        new keyVal("Moscow, Russia","http://ads.inasan.ru",""),
        new keyVal("Kiev, Ukraine","http://ads.mao.kiev.ua",""),
        new keyVal("Santiago, Chile","http://ads.astro.puc.cl",""),
        new keyVal("Rio de Janeiro, Brazil","http://ads.on.br",""),
        new keyVal("Tokyo, Japan","http://ads.nao.ac.jp",""),
        new keyVal("Beijing, China","http://ads.bao.ac.cn",""),
        new keyVal("Pune, India","http://ads.iucaa.ernet.in",""),
        new keyVal("Jakarta, Indonesia","http://ads.arsip.lipi.go.id","")};
    private JComboBox cb0 = new JComboBox(new DefaultComboBoxModel(ckv));
    private JComboBox cb1 = new JComboBox(new DefaultComboBoxModel(ckv));
    private JComboBox cb2 = new JComboBox(new DefaultComboBoxModel(ckv));
    private JComboBox cbm = new JComboBox(new DefaultComboBoxModel(mirror));
    private JSeparator sep0 = new JSeparator();
    private JSeparator sep1 = new JSeparator();
    private JSeparator sep2 = new JSeparator();

    private class keyVal {

        private String key;
        private String val;
        private String req;

        public keyVal(String key, String val, String req) {
            this.key = key;
            this.val = val;
            this.req = req;
        }

        @Override
        public String toString() {
            return key;
        }

        public String getKey() {
            return key;
        }

        public String getVal() {
            return val;
        }

        public String getReq() {
            return req;
        }
    }

    public JPanel getOptionsPanel() {
        JPanel pan = new JPanel();
        pan.setLayout(new java.awt.GridLayout(10, 1));
        pan.add(cb0);
        pan.add(sep0);
        pan.add(tf1);
        pan.add(cb1);
        pan.add(sep1);
        pan.add(tf2);
        pan.add(cb2);
        pan.add(exactCheckBox);
        pan.add(lbm);
        pan.add(cbm);
        cbm.setSelectedIndex(0);
        cb0.setSelectedIndex(1);
        return pan;
    }

    public String getHelpPage() {        
        return "http://ads.harvard.edu/cgi-bin/get_field_names.pl";
    }

    public URL getIcon() {        
        try{
            return new URL(getADSUrl() + "/favicon.ico");
        } catch(MalformedURLException ex){
            log.error(ex);
        }
        return GUIGlobals.getIconUrl("www");
    }

    public String getKeyName() {
        return "Search ADS";
    }

    public String getTitle() {
        return Globals.menuTitle(getKeyName());
    }

    public boolean processQuery(String key, ImportInspector dialog, OutputPrinter status) {
        try {

            /* Query ADS and load the results into the BibtexDatabase */
            status.setStatus(Globals.lang("Processing ") + key);
            BibtexDatabase bd = importADSEntries(key, status);
            if (bd == null) {
                return false;
            }
            /* Add the entry to the inspection dialog */
            int entryCount = bd.getEntryCount();

            if (dialog instanceof ImportInspectionDialog){
                ImportInspectionDialog d = (ImportInspectionDialog)dialog;
                d.setIconImage(ImageIO.read(getIcon()));
                d.setTitle(Globals.lang("Search results") + " " + Globals.lang("for") +": " + key + " ("+entryCount+")");
            }

            status.setStatus("Adding fetched entries: " + entryCount);
            if (entryCount > 0) {
                int i = 0;
                for (BibtexEntry entry : bd.getEntries()) {
                    i++;
                    dialog.setProgress(i, entryCount);
                    dialog.addEntry(entry);
                }
            }
            


        } catch (Exception e) {
            status.setStatus(Globals.lang("Error while fetching from ADS") + ": " + e.getMessage());
            log.error(e.getMessage());
        }
        return true;
    }

    public void stopFetching() {
    }

    private String getADSUrl(){
        keyVal kv = (keyVal) cbm.getSelectedItem();
        return kv.getVal();
    }

    private BibtexDatabase importADSEntries(String key, OutputPrinter status) {
        String url = getADSUrl() + "/cgi-bin/abs_connect?data_type=BIBTEXPLUS&nr_to_return=500&return_req=no_params&";
        try {
            if (exactCheckBox.isSelected()) {
                url += "aut_xct=YES&";
            }
            if (cb0.getSelectedIndex() > 0) {
                keyVal kv = (keyVal) cb0.getSelectedItem();
                url += kv.getReq() + "&" + kv.getVal() + URLEncoder.encode(key, "US-ASCII") + "&";
            } else if (key.indexOf("=") > 0) {
                url += URLEncoder.encode(key, "US-ASCII");
            } else {
                log.error("Not valid search key : " + key);
                status.showMessage("Please select or enter keyword");
                return null;
            }

            if (cb1.getSelectedIndex() > 0) {
                keyVal kv = (keyVal) cb1.getSelectedItem();
                url += kv.getReq() + "&" + kv.getVal() + URLEncoder.encode(tf1.getText(), "US-ASCII") + "&";
            } else if (tf1.getText().indexOf("=") > 0) {
                url += URLEncoder.encode(tf1.getText(), "US-ASCII") + "&";
            }
            if (cb2.getSelectedIndex() > 0) {
                keyVal kv = (keyVal) cb2.getSelectedItem();
                url += kv.getReq() + "&" + kv.getVal() + URLEncoder.encode(tf2.getText(), "US-ASCII") + "&";
            } else if (tf1.getText().indexOf("=") > 0) {
                url += URLEncoder.encode(tf1.getText(), "US-ASCII") + "&";
            }

            log.info("ADS URL: " + url);
            URL ADSUrl = new URL(url);
            HttpURLConnection ADSConnection = (HttpURLConnection) ADSUrl.openConnection();
            ADSConnection.setRequestProperty("User-Agent", "Jabref");
            ParserResult pr = BibtexParser.parse(new BufferedReader(new InputStreamReader(ADSConnection.getInputStream())));
            return pr.getDatabase();
        } catch (IOException e) {
            status.showMessage(Globals.lang(
                    "An Exception ocurred while accessing '%0'", url)
                    + "\n\n" + e.toString(), Globals.lang(getKeyName()), JOptionPane.ERROR_MESSAGE);
        } catch (RuntimeException e) {
            status.showMessage(Globals.lang(
                    "An Error occurred while fetching from ADS (%0):", new String[]{url})
                    + "\n\n" + e.getMessage(), Globals.lang(getKeyName()), JOptionPane.ERROR_MESSAGE);
        }
        return null;
    }
}
